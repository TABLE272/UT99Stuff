This a back up of the default NetGames USA skin that was installed with Unreal Tournament. If something goes wrong with any skins you try you can always use this skin to get back to a workable mode.

Just copy everything in this directory which includes the "skin.css" file and the "custom_graphics" directory back up one level to your UnrealTournament\NetGamesUSA.com\ngStats\html\skins directory and replace all the files there.

If you have difficulty or would like extra help using or creating custom skins please visit the ngStats for Unreal Tournament page at http://www.NetGamesUSA.com/ngStats/UT/

Thanks and have fun!

NetGames USA
The Computer Gaming Fun Factor Enhancement Company

http://www.NetGamesUSA.com/


